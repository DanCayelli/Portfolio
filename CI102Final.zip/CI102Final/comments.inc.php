<?php

function setComments($conn) {

// echo '<pre>';
// 	print_r($_POST);

	if(isset($_POST['max'])){
	$max = $_POST['max'];
	for ($i=0; $i <= $max; $i++) 
	{
		$message = 'message'.$i;
		if (isset($_POST[$message]) && $_POST[$message] != ''){
		$post_id = 'post_id'.$i;
		$date = 'date'.$i;
		$uid = 'uid'.$i;
		$uid = $_POST[$uid];
		$date = $_POST[$date];
		$message = $_POST[$message];
		$post_id = $_POST[$post_id];


		$sql = "INSERT INTO comments (post_id,uid, date, message) VALUES ('$post_id', '$uid','$date','$message')";
		$result = $conn->query($sql);

	}
}


	

}


}

function getComments($conn, $post_id){

$sql = "SELECT * FROM comments WHERE post_id = '".$post_id."'";
$result = $conn->query($sql);
echo "<div class='comment-box post-".$post_id."' id = '".$post_id."' style='display: none; margin: auto;'   >";

while ( $row = $result->fetch_assoc()) { 
	echo $row['uid']." - ".$row['date']."<br>";
	echo nl2br($row['message']."<br><br>");


	
}
echo "</div>";
}