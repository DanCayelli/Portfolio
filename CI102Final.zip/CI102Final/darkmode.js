const toggleSwitch = document.querySelector('.theme-switch input[type="checkbox"]');
const currentTheme = localStorage.getItem('theme');

if (currentTheme) {
    document.documentElement.setAttribute('data-theme', currentTheme);
    document.getElementById("darkmodeIndicator").innerHTML = "Enable Dark Mode!";
  
    if (currentTheme === 'dark') {
        toggleSwitch.checked = true;
        document.getElementById("darkmodeIndicator").innerHTML = "Enable Light Mode!";
    }
}

function switchTheme(e) {
    if (e.target.checked) {
        document.documentElement.setAttribute('data-theme', 'dark');
        document.getElementById("darkmodeIndicator").innerHTML = "Enable Light Mode!";
        localStorage.setItem('theme', 'dark');
    }
    else {
        document.documentElement.setAttribute('data-theme', 'light');
        document.getElementById("darkmodeIndicator").innerHTML = "Enable Dark Mode!";
         localStorage.setItem('theme', 'light');
    }    
}

toggleSwitch.addEventListener('change', switchTheme, false);