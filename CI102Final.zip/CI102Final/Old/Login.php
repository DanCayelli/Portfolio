`
<?php  include('Server.php'); ?>


<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
			<link rel="stylesheet" type="text/css" href="Stylesheet[1].css">

</head>
<body>

	<div class="container">
		<div class="headers">
			
<h2>Log In</h2>

		</div>



<form action="Login.php" method="post">
	
<div>
	<label for="username">Username</label>
	<input type="text" name="username" required>
</div>
 

<div>
	<label for="password">Password</label>
	<input type="password" name="password_1" required>
</div>



<button type="submit" name="login_user">Log In</button>


<P>Not a user?<a href="Registration.php"><b>Create an Account</b></a></P>

</form>