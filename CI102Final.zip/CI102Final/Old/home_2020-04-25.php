
<?php
date_default_timezone_set('America/New_York');
include 'dbh.inc.php';
include 'comments.inc.php';


?>
<?php
include "new.php";
$images_sql = "SELECT * from images ORDER BY id desc limit 1";
$result = mysqli_query($con, $images_sql);
$row = mysqli_fetch_array($result);
$filename = $row['name'];
$image = $row['image'];
$post_id = $row['id'];
?>
<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="Stylesheet.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>Home</title>
</head>

<body>
	<div class="titleBlock">
		<header>
			<h1>DripCheck</h1>
		</header>
	</div>
	<div class="sidenav">
		<a href="./home.php">Home</a>
		<a href="./post.php">Post</a>
		<a href="#contact">Contact</a>
	</div>
	<div class="feed">
		<div class="post">
			<img src="<?= $image ?>" width='300px' height='300px'>
		<?php echo "<form method='POST' action='".setComments($conn, $post_id)."'>
		<input type='hidden' id='User' name='uid' value='Anonymous'>
		<input type='hidden' name='post_id' value='".$post_id."'>
		<input type='hidden' name='date' value ='".date('Y-m-d H:i:s')."'>
		<textarea name='message'></textarea><br>
		<button type='submit' name='commentSubmit'>Comment</button>
		</form>
		";
		getComments($conn, $post_id);
		?>
    </div>
        
</body>
</html>
