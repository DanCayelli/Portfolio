<!DOCTYPE html>
<html>

    <head>
        <meta charset="utf-8"/>
        <title> Super Simple Registration System With PHP &amp; MySQL</title>

        <!-- The main CSS file -->
        <link href="Stylesheet.css" rel="stylesheet" />

        <!--[if lt IE 9]>
            <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
    </head>

    <body>

        <form id="login-register" method="post" action="index.php">

            <h1>Login or Register</h1>

            <input type="text" placeholder="your@email.com" name="email" autofocus />
            <p>Enter your email address above and we will send <br />you a login link.</p>

            <button type="submit">Login / Register</button>

            <span></span>

        </form>

        <!-- JavaScript Includes -->
        <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <script src="app.js"></script>

    </body>
</html>