/*var uploads = []
const postName = document.getElementById('postName');

function tester() {
  console.log(document.getElementById('postName'));
}

images = []

// A function will be created here to take the paths
// of the images and store them in the array above
// with their post ids so they can be added onto the
// feed so that

function showImage(images) {
  var x = document.createElement("IMG");
  x.setAttribute("src", images);
  x.setAttribute('id',images)
  document.body.appendChild(x);
}*/

$(function(){

  var form = $('#login-register');

  form.on('submit', function(e){

      if(form.is('.loading, .loggedIn')){
          return false;
      }

      var email = form.find('input').val(),
          messageHolder = form.find('span');

      e.preventDefault();

      $.post(this.action, {email: email}, function(m){

          if(m.error){
              form.addClass('error');
              messageHolder.text(m.message);
          }
          else{
              form.removeClass('error').addClass('loggedIn');
              messageHolder.text(m.message);
          }
      });

  });

  $(document).ajaxStart(function(){
      form.addClass('loading');
  });

  $(document).ajaxComplete(function(){
      form.removeClass('loading');
  });
});
