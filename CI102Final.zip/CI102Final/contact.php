<!DOCTYPE html>
<!--
    Name of File: contact.html  
    Purpose of File: This serves as a quick reference to the project designers and their positions for any users who want to contact them formally.
    Version and date: Final Doccumented Version  8 June 2020 
    Author(s): Cristos Criniti
    Dependencies: darkmode.js Stylesheet.css
-->
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="Stylesheet[1].css">
	<title>Contact</title>
</head>

<body>
	<div class="titleBlock">
		<header> <!-- This our Header -->
		<div class="theme-switch-wrapper"> <!-- switch between light and dark modes -->
				<label class="theme-switch" for="checkbox">
				<input type="checkbox" id="checkbox" />
				<div class="slider round"></div>
   
				</label>
   
				<em id="darkmodeIndicator">Enable Dark Mode!</em>
			</div>
			<h1>DripCheck</h1>
		</header>
	</div>
	<div class="sidenav"> <!-- This is our navigation bar -->
		<a href="./home.php">Home</a>
		<a href="./post.php">Post</a>
		<a href="./Login.php">Login</a>
		<a href="./contact.php">Contact</a>
	</div>
	<div class="feed"> <!-- defines the Developers' names and contact information -->
		<div class="post" style="color: Grey;">
			<h1>Product Owner: Matthew Cerny</h1><p>Email: matthew.blake.cerny@drexel.edu</p>
			<h1>Front-end Developer: Cristos (CJ) Criniti</h1><p>Email: cristos.james.criniti@drexel.edu</p>
			<h1>Back-end Developer: Ryan Alam</h1><p>Email: mohammed.alam@drexel.edu</p>
			<h1>Back-end Developer: Dan Cayelli</h1><p>Email:daniel.vctor.cayelli@drexel.edu</p>
		</div>
    </div>
    <script src="darkmode.js"></script>    
</body>
</html>