<?php  include('Server.php'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>Registration</title>
	<link rel="stylesheet" type="text/css" href="Stylesheet[1].css">
	
</head>
<body>

	<div class="titleBlock">
        <header>
		<div class="theme-switch-wrapper">
				<label class="theme-switch" for="checkbox">
				<input type="checkbox" id="checkbox" />
				<div class="slider round"></div>
   
				</label>
   
				<em id="darkmodeIndicator">Enable Dark Mode!</em>
			</div>
            <h1>DripCheck</h1>
        </header>
	</div>
			<div class="sidenav">
		<a href="./home.php">Home</a>
		<a href="./post.php">Post</a>
		<a href="./Login.php">Login</a>
		<a href="./contact.php">Contact</a>
	</div>


<div class="uploadBackground">
	<div>
			
		<h2>Register</h2>
			
	</div>
	<form action="Registration.php" method="post">
		

	<?php include('Errors.php') ?>

	<div style="margin-top: 5px ">
		<label for="username">Username</label>
		<input type="text" name="username" required>
	</div>

	<div style="margin-top: 5px ">
		<label for="email">Email</label>
		<input type="email" name="email" required>
	</div>

	<div style="margin-top: 5px ">
		<label for="password">Password</label>
		<input type="password" name="password_1" required>
	</div>

	<div style="margin-top: 5px " >
		<label for="password">Confirm Password</label>
		<input type="password" name="password_2" required>
	</div>
<div style="margin-top: 5px ">
	<button type="submit" name="reg_user" >Submit</button>
</div>
	<P>Already a user?<a href="Login.php"><b>Log in</b></a></P>

	</form>

</div>
<script src="darkmode.js"></script>
</body>
</html>