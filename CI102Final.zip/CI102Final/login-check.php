<?php 

?>
<div class="sidenav">
		<a href="./home.php">Home</a>
		<a href="./post.php">Post</a>
		<a href="./Login.php">Login</a>
		<a href="./contact.html">Contact</a>	</div>
	<div class="feed">
	
