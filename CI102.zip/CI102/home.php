
<?php
date_default_timezone_set('America/New_York');
include 'dbh.inc.php';
include 'comments.inc.php';


?>
<?php
include "new.php";
$images_sql = "SELECT * from images ORDER BY id asc";
$result = mysqli_query($con, $images_sql);
$image_list = array();
while ($row = mysqli_fetch_array($result)){

$image_list[]=$row;
$filename = $row['name'];
$image = $row['image'];
$post_id = $row['id'];}
$max=$post_id;

//print_r($image_list);

?>
<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="Stylesheet[1].css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>Home</title>
</head>

<body>
	<div class="titleBlock">
		<header>
			<h1>DripCheck</h1>
		</header>
	</div>
	<div class="sidenav">
		<a href="./home.php">Home</a>
		<a href="./post.php">Post</a>
		<a href="#contact">Contact</a>
	</div>
	<div class="feed">
		<div class="post">
		<?php 

		echo "<form name= 'Form' method='POST' action='".setComments($conn)."'>" ;

		for ($i=0; $i < $max; $i++) {
	


		echo "<img src='".$image_list[$i]['image']."' width='300px' height='300px'>
		
		<input type='hidden' id='User".$image_list[$i]['id']."' name='uid".$image_list[$i]['id']."' value='Anonymous'>
		<input type='hidden' name='post_id".$image_list[$i]['id']."' value='".$image_list[$i]['id']."'>
		<input type='hidden' name='date".$image_list[$i]['id']."' value ='".date('Y-m-d H:i:s')."'>
		<textarea name='message".$image_list[$i]['id']."'></textarea><br>
		<input type='hidden' value=".$max." name='max' >
		<button type='submit' name='commentSubmit".$image_list[$i]['id']."'>Comment</button>
		
		";


		getComments($conn, $image_list[$i]['id']);
		}

		?>
		</form>
    </div>
        
</body>
</html>
