
<?php
date_default_timezone_set('America/New_York');
include 'dbh.inc.php';
include 'comments.inc.php';


?>
<?php
include "new.php";
$images_sql = "SELECT * from images ORDER BY id asc";
$result = mysqli_query($con, $images_sql);
$image_list = array();
while ($row = mysqli_fetch_array($result)){

$image_list[]=$row;
$filename = $row['name'];
$image = $row['image'];
$post_id = $row['id'];}
$max=$post_id;

//print_r($image_list);
echo $image_list[2]['name'];
echo $post_id;
?>
<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="Stylesheet.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>Home</title>
</head>

<body>
	<div class="titleBlock">
		<header>
			<h1>DripCheck</h1>
		</header>
	</div>
	<div class="sidenav">
		<a href="./home.php">Home</a>
		<a href="./post.php">Post</a>
		<a href="#contact">Contact</a>
	</div>
	<div class="feed">
		<div class="post">
		<?php 

		for ($i=0; $i < $max; $i++) {
	


		//echo "<img src='".$image_list[$i]['image']."' width='300px' height='300px'>";
		// echo "<form method='POST' action='".setComments($conn,$image_list[$i]['id'])."'>
		// <input type='hidden' id='User' name='uid' value='Anonymous'>
		// <input type='hidden' name='post_id' value='".$image_list[$i]['id']."'>
		// <input type='hidden' name='date' value ='".date('Y-m-d H:i:s')."'>
		// <textarea name='message'></textarea><br>
		// <button type='submit' name='commentSubmit'>Comment</button>
		// </form>
		// ";

	}
	

		for ($i=0; $i < $max; $i++) {
		echo "<img src='".$image_list[$i]['image']."' width='300px' height='300px'>";
		echo "<form action='".setComments($conn,$image_list[$i]['id'])."'>
		<input type='hidden' id='User' name='uid' value='Anonymous'>
		<input type='hidden' name='post_id' value='".$image_list[$i]['id']."'>
		<input type='hidden' name='date' value ='".date('Y-m-d H:i:s')."'>
		<textarea name='message'></textarea><br>
		<button type='submit' name='commentSubmit'>Comment</button>
		</form>
		";
		getComments($conn, $image_list[$i]['id']);
		}
		
		?>
    </div>
        
</body>
</html>
